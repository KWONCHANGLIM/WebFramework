mvn package
mvn tomcat7:run Ȥ��
mvn -X tomcat7:run-war

http://127.0.0.1:8080/mvn04/member/list