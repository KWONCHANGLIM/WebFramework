package spms.vo;

import java.util.Date;

public class Temperature{
   protected int 	no;
   protected double	temp;
	
	public int getNo() {
		return no;
	}
	public Temperature setNo(int no) {
		this.no = no;
		return this;
	}
	public Double getTemp() {
		return temp;
	}
	public Temperature setTemp(double temp) {
		this.temp = temp;
		return this;
	}
	
}
