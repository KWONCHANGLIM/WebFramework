var express = require('express'),
    http = require('http'),
    app = express(),
    server = http.createServer(app) ;
var bodyParser = require('body-parser') ;
var SerialPort = require('serialport').SerialPort,
    serial = new SerialPort('/dev/ttyACM0', {
    baudrate : 115200
  }) ;


app.use(bodyParser.json()) ;
app.use(bodyParser.urlencoded({ extended : false })) ;

app.get('/serial', function (req, res) {
    res.sendfile('server.html', {root : __dirname }) ;
  }) ;

app.post('/serial', function (req, res) {
    var val = req.body.send ;
    console.log(val) ;
    serial.write(val, function(err) {}) ;
    res.sendfile('server.html', {root : __dirname }) ;
  }) ;

serial.on('data', function(data) {
    console.log(data.toString()) ;
  }) ;

server.listen(8000, function() {
    console.log('Express server listening on port ' + server.address().port) ;
  }) ;

