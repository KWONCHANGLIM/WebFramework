import serial
import MySQLdb
import time
from time import localtime, strftime 
 
ser = serial.Serial('/dev/ttyACM0',9600)
db = MySQLdb.connect(host='localhost', user='study', passwd = 'study',db='studydb')
 
cur = db.cursor()
 
while 1:
    print("Waiting for data...")
    print("")
    x = ser.readline()
    print("Colletciong data...")
    print("")
    time.sleep(1)
    x = x[:-2]
    print("Inserting to databe...")
    print("")
    time.sleep(10)
    sql = "INSERT INTO tempLog(temp) VALUES (%s)" %(x)
    cur.execute(sql)
    db.commit()
